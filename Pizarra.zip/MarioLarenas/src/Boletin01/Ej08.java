package Boletin01;
import java.util.Scanner;

public class Ej08 {
	private static Scanner sc;
	public static void main(String[] args) {
		double a, b;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese numero uno : ");
		a=sc.nextDouble();
		System.out.print("Ingrese numero dos : ");
		b=sc.nextDouble();	
		if (a>b) {
			System.out.println(a+" es mayor a "+b);}
			else if(b>a){
				System.out.println(b+" es mayor a "+a);} 
				else {
					System.out.println("Son iguales ");}
		sc.close();		
	}	
}
