package Boletin01;
import java.util.Scanner;

public class Ej04 {
	private static Scanner sc;
	public static void main(String[] args) {
		double a, b;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese numero uno : ");
		a=sc.nextDouble();
		System.out.print("Ingrese numero dos : ");
		b=sc.nextDouble();	
		if (a==b) {
			System.out.println("Los numeros son iguales");
		} else {
			System.out.println("Los numeros son distintos");
		}
		sc.close();		
	}	
}
