package Boletin01;
import java.util.Scanner;

public class Ej07 {
	private static Scanner sc;
	public static void main(String[] args) {
		double a, b;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese numero uno : ");
		a=sc.nextDouble();
		System.out.print("Ingrese numero dos : ");
		b=sc.nextDouble();	
		
		System.out.println("max(" + a + "," + b + ") es " + Math.max(a,b));
		sc.close();		
	}	
}
