package Boletin01;
import java.util.Scanner;

public class Ej06 {
	private static Scanner sc;
	public static void main(String[] args) {
		double a, b, c;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese numero uno : ");
		a=sc.nextDouble();
		System.out.print("Ingrese numero dos : ");
		b=sc.nextDouble();	
		c= a%b;
		if (c==0) {
			System.out.println("Los numeros son multiplos ");
		} else {
			System.out.println("Los numeros no son multiplos ");
		}
		sc.close();		
	}	
}
