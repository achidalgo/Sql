package Boletin01;

import java.util.Scanner;
import java.lang.Math;//para pi

public class Ej01 {
	private static Scanner sc;
	public static void main(String[] args) {
		double a, b, c, x1, x2 ;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese a : ");
		a=sc.nextDouble();
		System.out.print("Ingrese b : ");
		b=sc.nextDouble();	
		System.out.print("Ingrese c : ");
		c=sc.nextDouble();	
		x1=(-b+Math.sqrt((b*b)-(4*a*c)))/(2*a);
		x2=(-b-Math.sqrt((b*b)-(4*a*c)))/(2*a);
        System.out.format("x1 = %.2f and x2 = %.2f", x1, x2);

		sc.close();		
	}

}
