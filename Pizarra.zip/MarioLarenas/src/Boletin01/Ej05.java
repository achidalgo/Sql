package Boletin01;
import java.util.Scanner;

public class Ej05 {
	private static Scanner sc;
	public static void main(String[] args) {
		double a;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese numero : ");
		a=sc.nextDouble();
		if (a>0) {
			System.out.println("El numero es Positivo");
		} else {
			System.out.println("El numero es Negativo");
		}
		sc.close();		
	}	
}
