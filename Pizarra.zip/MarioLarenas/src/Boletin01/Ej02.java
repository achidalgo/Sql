package Boletin01;
import java.util.Scanner;
import java.lang.Math;//para pi

public class Ej02 {
	private static Scanner sc;
	public static void main(String[] args) {
		double f, area;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese radio de un circulo : ");
		f=sc.nextDouble();
		area=Math.PI*Math.pow(f, 2);
		//System.out.println(Math.PI);
		System.out.println("El area del circulo es : "+ area);
		sc.close();
	}

}
