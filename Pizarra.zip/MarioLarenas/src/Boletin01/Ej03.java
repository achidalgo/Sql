package Boletin01;
import java.util.Scanner;
import java.lang.Math;//para pi

public class Ej03 {
	private static Scanner sc;
	public static void main(String[] args) {
		double f, longuitud;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese radio de un circulo : ");
		f=sc.nextDouble();
		longuitud=2*Math.PI*f;
		System.out.println("La longuitud del circulo es : "+ longuitud);
		
		sc.close();
	}
}
