package Calculadora;

//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculadoraTestJupiter {

	@Test
	public void TestSuma() {
		int resultado=Calculadora.suma(3, 5);
		int esperado=8;
		assertEquals(esperado,resultado);
	}
	@Test
	public void TestResta() {
		int resultado=Calculadora.resta(3, 5);
		int esperado=-2;
		assertEquals(esperado,resultado);
	}
}
