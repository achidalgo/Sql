package Guia01;
import java.util.Scanner;
public class ej05 {
	
	private static Scanner dato; 
	public static void main(String[] args) {
	int  suma, x, y;
	dato=new Scanner(System.in);
	
	y=0;
	System.out.print("Ingrese cantidad : ");
	y=dato.nextInt();
	
	System.out.println(" NUMEROS IMPARES ");	
	suma=0;
	x=1;

	while (x<=y){
		System.out.print("Impar "+(x)+" ");
		suma=suma+x;
		x=x+2;
	}
	System.out.println();
	System.out.println("La suma de impares es: "+suma);
	
	System.out.println(" NUMEROS PARES ");	
	suma=0;
	x=0;

	while (x<=y){
		System.out.print("Par "+(x)+" ");
		suma=suma+x;
		x=x+2;
	}
	System.out.println();
	System.out.println("La suma de pares es: "+suma);
	
	System.out.println(" NUMEROS MULTIPLOS DE 3 ");	
	suma=0;
	x=0;

	while (x<=y){
		System.out.print("Multiplo de tres "+(x)+" ");
		suma=suma+x;
		x=x+3;
	}
	System.out.println();
	System.out.println("La suma de multiplos de tres es: "+suma);
	
	System.out.println(" NUMEROS MULTIPLOS DE 5 ");	
	suma=0;
	x=0;

	while (x<=y){
		System.out.print("Multiplo de cinco "+(x)+" ");
		suma=suma+x;
		x=x+5;
	}
	System.out.println();
	System.out.println("La suma de multiplos de cinco es: "+suma);
}	

}
