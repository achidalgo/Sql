package Guia01;
public class ej04 {
	
	public static void main(String[] args) {
	int x, y;

	x=1;
	y=100;

	while(x<=y) {
		System.out.println("Numero Par: "+(x*2));
        x=x+1;
	}
}	

}
