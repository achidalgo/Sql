package Guia01;
import java.util.Scanner;

public class ej02 {
	private static Scanner dato; 
	public static void main(String[] args) {
	int num, suma;
	dato=new Scanner(System.in);

	suma=0;
	// int suma=0;
	for (int x=0; x<10; x++)
	//(int x=5; x>0; x--)
	{
		System.out.print("Ingrese numero a sumar "+(x+1)+" ");
        num=dato.nextInt();
        //int num=dato.nextInt();
        suma=suma+num;
	}
	System.out.print("El resultado es: "+suma);
}	
}
