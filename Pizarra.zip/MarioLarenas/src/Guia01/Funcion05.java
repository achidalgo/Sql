package Guia01;
/*La funcion 5. Ingresar N numeros y que pare al ingresar un cero. 
 * Al terminar me diga la cantidad de numeros ingresados excluyendo 
 * al cero adem�s de el promedio de estos
*/
import java.util.Scanner;

public class Funcion05 {

		private static Scanner dato; 
		public static void main(String[] args) {
		int num, suma;
		dato=new Scanner(System.in);

		suma=0;
		// int suma=0;
		for (int x=0; x<10; x++)
		//(int x=5; x>0; x--)
		{
			System.out.print("Ingrese numero a sumar "+(x+1)+" ");
	        num=dato.nextInt();
	        //int num=dato.nextInt();
	        suma=suma+num;
		}
		System.out.print("El resultado es: "+suma);
	}
		
	}


