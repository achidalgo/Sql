package Guia01;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=0;
		int y=10;
		while(x<y){
			System.out.println("Vuelta del while : "+x);
			x=x+1;
		}

	}

}
