package Guia01;
import java.util.Scanner;
public class ej03 {
	
	private static Scanner dato; 
	public static void main(String[] args) {
	int num, suma, x, y;
	dato=new Scanner(System.in);

	suma=0;
	x=0;
	y=0;
	System.out.print("Ingrese cantidad : ");
	y=dato.nextInt();
	while(x<y) {
		System.out.print("Ingrese numero a sumar "+(x+1)+" ");
        num=dato.nextInt();
        //int num=dato.nextInt();
        suma=suma+num;
        x=x+1;
	}
	System.out.print("El resultado es: "+suma);
}	

}
