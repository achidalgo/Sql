/* 1.-Hacer el diagramade flujopara sumar dos 
 * n�meros le�dos por teclado y escribir el resultado*/

package Guia01;

import java.util.Scanner;

public class ej01 {
	private static Scanner sc; //la declara aca
	public static void main(String[] args) { 
	int num1, num2, suma;
	
	// Scanner sc= new Scanner(System.in);
	sc= new Scanner(System.in);
	System.out.println("Ingrese el primer n�mero");
	num1= sc.nextInt();
	System.out.println("Ingrese el segundo n�mero");
	num2= sc.nextInt();	
	suma=num1+num2;
	System.out.println("La suma es:"+suma);	
	}
}
