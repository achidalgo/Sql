package Guia01;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=0;
		do{
			x=x+1;
			System.out.println("Vuelta do while numero:"+x);
		}while (x<5);
	}
}
