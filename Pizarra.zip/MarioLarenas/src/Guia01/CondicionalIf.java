package Guia01;

import java.util.Objects;
import java.util.Scanner;

public class CondicionalIf {

	public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	System.out.println("Desea Comer");
	System.out.println("A. Si");
	System.out.println("B. No");
	//int op= sc.nextInt();
	String op= sc.next();
	//con numeros == con string usar equals
	if (Objects.equals(op,"A")|| Objects.equals(op,"a")) {
		System.out.println("Valla a comer");
	} else {
		System.out.println("Muera de hambre"+op+"::");
	}
	sc.close();
	}

}
