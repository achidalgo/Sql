package Guia01;
//import javax.swing.JOptionPane;
public class HolaCurso {

	public static void main(String[] args) {
		
		//System.out.println("Hola curso");
		//System.out.println(56);
		//System.out.println();
		//JOptionPane.show
	//	JOptionPane.showMessageDialog(frame, "A basic JOptionPane message dialog");		
	}
	
}
