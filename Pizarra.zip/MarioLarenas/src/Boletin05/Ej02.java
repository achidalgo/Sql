package Boletin05;

import java.util.Scanner;

public class Ej02 {

	private static Scanner sc;

	public static void main(String[] args) {
	sc = new Scanner(System.in);
	
	int t[][]= new int[3][3];

	for (int i=0;i<3;i++) {
		for (int j=0;j<3;j++) {	
			System.out.print("Ingrese valor "+(i+1)+" "+(j+1)+" : ");		
			t[i][j]=sc.nextInt();
		}
	}
	System.out.println("La matrix quedaria de la siguiente forma: ");
	for (int i=0;i<3;i++) {
		System.out.println(t[i][0]+" "+t[i][1]+" "+t[i][2]);
	}
	
	System.out.println("****************");
	for (int i=0;i<3;i++) {
		System.out.println(t[0][i]+" "+t[1][i]+" "+t[2][i]);
	}	
	
//comparar 5 1 3 1 8 2 3 2 5
	
	
	boolean simetrica=true;
	
	for (int i=0; i<3;i++) {
		for (int j=0;j<3;j++) {
			if (t[i][j]!=t[j][i]) {
				simetrica=false;
			}
		}
		
	}
	System.out.println("*************************");
	if (simetrica) {
		System.out.println("La matriz es simetrica");
	} else {
		System.out.println("La matriz no es simetrica");
	}
	System.out.println("*************************");
	}
}
