package Boletin05;

import java.util.Scanner;

public class Ej05 {

	private static Scanner sc;

	public static void main(String[] args) {
	sc = new Scanner(System.in);
	
	int t[][]= new int[3][3];

	for (int i=0;i<3;i++) {
		for (int j=0;j<3;j++) {	
			System.out.print("Ingrese valor "+(i+1)+" "+(j+1)+" : ");		
			t[i][j]=sc.nextInt();
		}
	}
	System.out.println("La Matrix : ");
	for (int i=0;i<3;i++) {
		System.out.println(t[i][0]+" "+t[i][1]+" "+t[i][2]);
	}
	
	System.out.println("Traspuesta : ");
	for (int i=0;i<3;i++) {
		System.out.println(t[0][i]+" "+t[1][i]+" "+t[2][i]);
	}	
	
	}
}
