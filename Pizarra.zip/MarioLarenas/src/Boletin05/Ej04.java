package Boletin05;

public class Ej04 {

	public static void main(String[] args) {
	
	int t[][]= new int[7][7];

	for (int i=0;i<7;i++) {
		for (int j=0;j<7;j++) {	
			if (i==j) {		
				t[i][j]=1;
			}else {
				t[i][j]=0;
			}
		}
	}
	System.out.println("La Matrix : ");
	for (int i=0;i<7;i++) {
		System.out.println(t[i][0]+" "+t[i][1]+" "+t[i][2]+" "+t[i][3]+" "+t[i][4]+" "+t[i][5]+" "+t[i][6]);
	}
	
	}
}
