package Boletin05;

import java.util.Scanner;

public class Ej11 {

	private static Scanner sc;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		final int TAM=10,Dorsal=0,M2000=1,M2001=2,M2002=3;
		//final me deja las variables con un unico valor de entrada durante todo el c�digo
		int opc,numc,dorsal,i,aux;
		boolean d_rep,inter;
		int participante[][]=new int[TAM][4];
		String nombre[]=new String[TAM];
		numc=0;
		opc=0;
		
		do {
	        					
			System.out.println(" ");
			System.out.println("********************************");
			System.out.println("1. Inscribir participantes");
			System.out.println("2. Mostrar listado por datos");
			System.out.println("3. Mostrar listado por marcas");
			System.out.println("4. Salir");
			System.out.println("********************************");
			opc=sc.nextInt();
			System.out.println();
			
								
			switch(opc){
			
			case 1:
					if(numc==10)
						System.out.println("Listado completo");
					else{
						do{
							System.out.print("Introduzca dorsal: ");
							dorsal=sc.nextInt();
							d_rep=false;
							i=0;
							while(i<numc && d_rep==false){
			
								if(participante[i][Dorsal]==dorsal){
									System.out.print("Dorsal registrado.");
									System.out.println("Por favor intente de nuevo");
									d_rep=true;
								}
								i++;
							}
						}while(d_rep==true);
					if(d_rep==false){
						System.out.print("Introduzca nombre participante: ");
						nombre[numc]=sc.next();
						participante[numc][Dorsal]=dorsal;
						System.out.print("Introduzca marca del 2000: ");
						participante[numc][M2000]=sc.nextInt();
						System.out.print("Introduzca marca del 2001: ");
						participante[numc][M2001]=sc.nextInt();
						System.out.print("Introduzca marca del 2002: ");
						participante[numc][M2002]=sc.nextInt();
						System.out.println();
						numc++;
					}
				   }
			break;
			
			case 2: // m�todo de ordenaci�n por burbuja, controlado por intercambio
				inter=true;
				while(inter==true){
					inter=false;
					for (int j=0;j<=numc-1-1;j++){
						if(participante[j][Dorsal]>participante[j+1][Dorsal]){
							for (int k=0;k<4;k++){
								aux=participante[j][k];
								participante[j][k]=participante[j+1][k];
								participante[j+1][k]=aux;
							}
							inter=true;
						}
					}
				}
				System.out.println("LISTADO DE DATOS POR DORSAL:");
				System.out.println ("dorsal - marcas");
				for (int j=0;j<numc;j++){
					System.out.println();
					for (int k=0;k<4;k++){
						System.out.print(participante[j][k]+" ");
					}
				}
				break;
			case 3:
		
					inter=true;
					while(inter==true){
						inter=false;
						for (int j=0;j<=numc-1-1;j++){
							if(participante[j][M2002]>participante[j+1][M2002]){
								for (int k=0;k<4;k++){
									aux=participante[j][k];
									participante[j][k]=participante[j+1][k];
									participante[j+1][k]=aux;
								}
								inter=true;
							}
						}
					}
					System.out.println("LISTADO POR MARCAS:");
					System.out.print(" ");
					for (int j=0;j<numc;j++){
						System.out.println(nombre[j]+" :");
						System.out.println("Dorsal - M(2000-2001-2002): ");
						for (int k=0;k<4;k++){
							System.out.print(participante[j][k]+"      ");
						}
					}
					
					break;
					}
		 	} 
		 	while(opc!=4);
		   
	}
}
