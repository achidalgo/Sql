package Boletin05;

//import java.util.Scanner;

public class Ej01 {

	//private static Scanner sc;

	public static void main(String[] args) {
	//sc = new Scanner(System.in);
	
	int t[][]= new int[5][5];

	for (int i=0;i<5;i++) {
		for (int j=0;j<5;j++) {	
			t[i][j]=i+j;
		}
	}
	System.out.println("La matrix quedaria de la siguiente forma: ");
	for (int i=0;i<5;i++) {
		System.out.println(t[i][0]+" "+t[i][1]+" "+t[i][2]+" "+t[i][3]+" "+t[i][4]);
	}
	
	}

}
