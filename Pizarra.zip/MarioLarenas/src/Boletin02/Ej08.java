package Boletin02;

import java.util.Scanner;

public class Ej08 {
	private static Scanner sc;		
	public static void main(String[] args) {
		int a=0;
		int i=0;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese un Numero : ");
		a=sc.nextInt();
		if (a>0) {
			for (i=1;i<=a;i++) {
				System.out.println(i);
			}
			}else {
				System.out.println("Ingrese un numero mayor a cero");
			}
	
		sc.close();		
	}
}
