package Boletin02;

import java.util.Scanner;

public class Ej01 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a;
		a=0;
		sc=new Scanner(System.in);
		do{
			System.out.print("Ingrese un Numero : ");
			a=sc.nextDouble();
			if (a>=0) {
				double resul=a*a;
				System.out.println("Su cuadrado es : "+resul);
			}else{
				System.out.println("Ingreso un Numero Negativo");
			}
		}while (a>0);
		sc.close();		
	}

}
