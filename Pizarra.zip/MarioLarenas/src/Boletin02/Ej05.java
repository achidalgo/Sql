package Boletin02;

import java.util.Random;
import java.util.Scanner;

public class Ej05 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a=0;
		double anterior=0;
		boolean moneda=true;//mayor
		boolean acerto=true;
		
		sc=new Scanner(System.in);
		Random numAleatorio = new Random();
		
		do{
			System.out.print("Ingrese un Numero : ");
			a=sc.nextDouble();
			
			if ((moneda && a>=anterior)||(!moneda && a<anterior)) {
				acerto=true;
				moneda = numAleatorio.nextBoolean();
				if (moneda)  {
				    System.out.println("Ingrese un numero Mayor ");
					} else {
						System.out.println("Ingrese un numero Menor ");
					}			
				anterior=a;				
				}
				else {
					acerto=false;
				}
			
		}while (acerto);
		System.out.println("Game Over");
		
		sc.close();		
	}
}
