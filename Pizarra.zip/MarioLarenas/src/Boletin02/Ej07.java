package Boletin02;

import java.util.Scanner;

public class Ej07 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a=0;
		double suma=0;
		int cont=0;
		sc=new Scanner(System.in);
		do{
			System.out.print("Ingrese un Numero : ");
			a=sc.nextDouble();
			if (a>0) {
				suma=suma+a;
				cont++;
			}
		}while (a>0);
		if (cont>0) {
			System.out.println("La media de los "+cont+" numeros es: "+(suma/cont));
		}else {
			System.out.println("No ha ingresado ningun numero valido");
		}
		sc.close();		
	}
}
