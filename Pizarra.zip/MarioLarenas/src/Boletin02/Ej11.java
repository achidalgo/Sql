package Boletin02;

public class Ej11 {
	
	public static void main(String[] args) {

		int multi=1;
		for(int i=1; i<=20; i++){
			System.out.println("Impar : "+i);
			multi=multi*i;
			i=i+1;	
		}
		System.out.println("El producto es : "+multi);		
	}
}
