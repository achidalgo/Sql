package Boletin02;

import java.util.Scanner;

public class Ej04 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a=0;
		int suma=0;
		sc=new Scanner(System.in);
		do{
			System.out.print("Ingrese un Numero : ");
			a=sc.nextDouble();
			if (a>=0) {
				suma++;
			}
		}while (a>=0);
		System.out.println("Se han ingresado "+suma+ " numeros");
		sc.close();		
	}
}
