package Boletin02;

import java.util.Scanner;

public class Ej12 {
	private static Scanner sc;		
	public static void main(String[] args) {
		int a=0;
		int fact=1;
		sc=new Scanner(System.in);
		
		System.out.print("Ingrese un Numero : ");
		a=sc.nextInt();		
		
		for(int i=1; i<=a; i++){
			fact=fact*i;
		}
		System.out.println("El factorial es : "+fact);
		sc.close();		
	}
}
