package Boletin02;

import java.util.Scanner;

public class Ej10 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a=0;
		double suma=0;
		sc=new Scanner(System.in);
		for(int i=1; i<=15; i++){
			System.out.print("Ingrese un Numero : "+i+" ");
			a=sc.nextDouble();
			suma=suma+a;
		}
		System.out.println("La suma es : "+suma);
		sc.close();		
	}
}
