package Boletin02;

import java.util.Scanner;

public class Ej13 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a=0;
		double suma_pos=0;
		double suma_neg=0;
		int cont_pos=0;
		int cont_neg=0;
		int cont_cero=0;
		
		sc=new Scanner(System.in);
		
		for(int i=1; i<=10; i++){
			System.out.print("Ingrese un Numero "+i+" : ");
			a=sc.nextDouble();
			if (a>0) {
				suma_pos=suma_pos+a;
				cont_pos++;
			}else if (a<0) {
				suma_neg=suma_neg+a;
				cont_neg++;				
			}else {
				cont_cero++;
			}
		}
		if (cont_pos>0) {
			System.out.println("La media positiva es : "+(suma_pos/cont_pos));
		}
		if (cont_neg>0) {
			System.out.println("La media negativa es : "+(suma_neg/cont_neg));
		}
		if (cont_cero>0) {
			System.out.println("La cantidad de ceros es : "+cont_cero);
		}
		sc.close();		
	}
}
