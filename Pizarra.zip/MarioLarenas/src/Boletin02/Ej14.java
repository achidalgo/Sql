package Boletin02;

import java.util.Scanner;

public class Ej14 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a=0;
		double suma=0;
		int cont=0;
		
		sc=new Scanner(System.in);
		for(int i=1; i<=10; i++){
			System.out.print("Ingrese un Sueldo "+i+" : ");
			a=sc.nextDouble();
			suma=suma+a;
			if (a>=1000) {
				cont++;
			}
		}
		System.out.println("La suma es : "+suma);
		System.out.println("Sueldos mayores a 1000 son : "+cont);
		sc.close();		
	}
}
