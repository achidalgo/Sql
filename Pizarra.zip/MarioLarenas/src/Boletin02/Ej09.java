package Boletin02;

public class Ej09 {	
	public static void main(String[] args) {
	
		for (int i=100;i>=0;i--) {
			System.out.println(i);
			i=i-6;
		}
	
	}
}
