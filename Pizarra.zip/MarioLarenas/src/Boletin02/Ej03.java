package Boletin02;

import java.util.Scanner;

public class Ej03 {
	private static Scanner sc;		
	public static void main(String[] args) {
		double a,c;
		a=0;
		sc=new Scanner(System.in);
		do{
			System.out.print("Ingrese un Numero : ");
			a=sc.nextDouble();
			c= a%2;
			if (c==0) {
				System.out.println("El numero es Par");
			}else {
				System.out.println("El numero es Impar");
			}
		}while (a!=0);
		sc.close();		
	}
}
