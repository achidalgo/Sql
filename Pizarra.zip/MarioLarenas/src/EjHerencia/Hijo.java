package EjHerencia;

public class Hijo extends Padre {

	public Hijo() {
		super();

	}

	public Hijo(String nombre, int edad, String rut, String tez, String color_ojos, String apellido, String domicilio,
			boolean cancer, boolean diabetes, boolean hta) {
		super(nombre, edad, rut, tez, color_ojos, apellido, domicilio, cancer, diabetes, hta);
	
	}
 
	public void jugar() {
		System.out.println("El hijo juega");
	}

}
