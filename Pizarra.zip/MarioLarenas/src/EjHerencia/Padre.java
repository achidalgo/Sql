package EjHerencia;

public class Padre {

	String nombre;
	int edad;
	String rut;
	String tez;
	String color_ojos;
	String apellido;
	String domicilio;
	boolean cancer;
	boolean diabetes;
	boolean hta;
	
	public Padre() {//constructor vacio
		super();
	}
	//constructor con parametros
	public Padre(String nombre, int edad, String rut, String tez, String color_ojos, String apellido, String domicilio,
			boolean cancer, boolean diabetes, boolean hta) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.rut = rut;
		this.tez = tez;
		this.color_ojos = color_ojos;
		this.apellido = apellido;
		this.domicilio = domicilio;
		this.cancer = cancer;
		this.diabetes = diabetes;
		this.hta = hta;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getTez() {
		return tez;
	}

	public void setTez(String tez) {
		this.tez = tez;
	}

	public String getColor_ojos() {
		return color_ojos;
	}

	public void setColor_ojos(String color_ojos) {
		this.color_ojos = color_ojos;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public boolean isCancer() {
		return cancer;
	}

	public void setCancer(boolean cancer) {
		this.cancer = cancer;
	}

	public boolean isDiabetes() {
		return diabetes;
	}

	public void setDiabetes(boolean diabetes) {
		this.diabetes = diabetes;
	}

	public boolean isHta() {
		return hta;
	}

	public void setHta(boolean hta) {
		this.hta = hta;
	}

	//crear un metodo
	
	public void trabajar(boolean resp) {
		if (resp==true) {
			if (getEdad()>65) 
				System.out.println("No deberia trabajar");
				else
					System.out.println("Gane Platita");
		}
	}
	
	public void dormir(boolean resp) {
		if (resp==true)
			System.out.println("Duerma entonces");
		else
			System.out.println("No moleste a los que quieren dormir");
	}
	
	public void comer() {
		System.out.println("Coma sano!!!");
		
	}
}
