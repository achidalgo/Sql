package EjHerencia;

import java.util.Scanner;

public class Principal {
	
	private static Scanner sc;

	public static void main(String[] args) {

	sc = new Scanner(System.in);
	
	Padre P1= new Padre("Juan", 25, "18765667-k", "Moreno", "Cafe", "Pacheco", "Chile", false, true, false);
	Padre P2= new Padre(); {
		P2.setNombre("Jose");
		System.out.println("Ingrese Apellido del molde P2 : ");
		P2.setApellido(sc.next());
	}
	
	System.out.println(P1.getNombre());
	System.out.println(P1.getApellido());
	System.out.println(P1.getEdad());
	System.out.println(P1.rut);
	
	System.out.println("");
	System.out.println("Quiere Trabajar");
	System.out.println("1. Si");	
	System.out.println("2. No");	
	int op=sc.nextInt();
	//P1.trabajar(P1.getEdad());
	
	if (op==1)
		P1.trabajar(true);
	else
		P1.trabajar(false);
	
	}
}
