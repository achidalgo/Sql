package POO_Herencia;

import java.util.Date;

public class Productos {
	String nombre;
	Date caducidad;
	long lote;	

	public Productos() {
		super();
	}

	public Productos(String nombre, Date caducidad, long lote) {
		super();
		this.nombre = nombre;
		this.caducidad = caducidad;
		this.lote = lote;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Date getCaducidad() {
		return caducidad;
	}

	public void setCaducidad(Date caducidad) {
		this.caducidad = caducidad;
	}

	public long getLote() {
		return lote;
	}

	public void setLote(long lote) {
		this.lote = lote;
	}

	
	
	
}
