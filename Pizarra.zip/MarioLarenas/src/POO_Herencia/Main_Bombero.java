package POO_Herencia;
import javax.swing.JOptionPane;
//import javax.swing.JFrame;
public class Main_Bombero {

	private static int x, y;

	public static void main(String[] args) {
	
    Bombero B1 = new Bombero("Pedro", "Vasquez", 25, true, true);
    Bombero B2 = new Bombero("Cata", "Pacheco", 21, false, true);
    Bombero B3 = new Bombero();
  
    B3.setNombre(JOptionPane.showInputDialog(null,"Ingrese Nombre"));
    B3.setApellidos(JOptionPane.showInputDialog(null,"Ingrese Apellidos"));
    B3.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese Edad"))); 
    
    x=JOptionPane.showConfirmDialog(null,"Es Casado", "Seleccione",
   		JOptionPane.YES_NO_OPTION);
    if (x==1)
    	B3.setCasado(false);
    else
    	B3.setCasado(true);
    
    y=JOptionPane.showConfirmDialog(null,"Es Especialista", "Seleccione",
   		JOptionPane.YES_NO_OPTION);
	if (y==1)
    	B3.setEspecialista(false);
    else
    	B3.setEspecialista(true);
    
    System.out.println(B1.getNombre()+" "+B1.getApellidos()+" "+B1.getEdad()+" "+B1.isCasado()+" "+B1.isCasado());
    System.out.println(B2.getNombre()+" "+B2.getApellidos()+" "+B2.getEdad()+" "+B2.isCasado()+" "+B2.isCasado());
    System.out.println(B3.getNombre()+" "+B3.getApellidos()+" "+B3.getEdad()+" "+B3.isCasado()+" "+B3.isCasado());
	}

}
