package POO_Herencia;

public class Main_Persona {

	public static void main(String[] args) {

    Empleado E1=new Empleado("Andres", 34, 0, 5);
    Practicante P1=new Practicante("Manuel", 18, 0, 0, 1);
    
    E1.calculosalario();
    P1.calculosalariopracticante();
    
	System.out.println();    
	System.out.print(E1.getNombre());
	System.out.println(E1.getSueldo());

	System.out.println();  	
	System.out.print(P1.getNombre());
	System.out.println(P1.getSueldo());
	
	}

}
