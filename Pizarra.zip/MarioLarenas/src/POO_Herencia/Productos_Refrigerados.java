package POO_Herencia;

import java.util.Date;

public class Productos_Refrigerados extends Productos {

	String organismo;
	
	public Productos_Refrigerados() {
		super();
	}

	public Productos_Refrigerados(String nombre, Date caducidad, long lote, String organismo) {
		super(nombre, caducidad, lote);
		this.organismo = organismo;
	}

	public String getOrganismo() {
		return organismo;
	}

	public void setOrganismo(String organismo) {
		this.organismo = organismo;
	}

}
