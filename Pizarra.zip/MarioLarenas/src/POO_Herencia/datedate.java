package POO_Herencia;

import javax.swing.JOptionPane;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;

public class datedate {
	
	public static Date ParseFecha(String fecha)
    {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaDate = null;
        try {
            fechaDate = formato.parse(fecha);
        } 
        catch (ParseException ex) 
        {
            System.out.println(ex);
        }
        return fechaDate;
    }

	public static void main(String[] args) throws ParseException {

        MaskFormatter formatter = new MaskFormatter("##-##-####");
        JFormattedTextField textField = new JFormattedTextField(formatter);
        JOptionPane.showMessageDialog(null, textField);	
	}

}
