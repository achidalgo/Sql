package POO_Herencia;

import java.util.Date;

public class Productos_Congelados extends Productos {

	int temperatura;
	
	public Productos_Congelados() {
		super();
	}

	public Productos_Congelados(String nombre, Date caducidad, long lote, int temperatura) {
		super(nombre, caducidad, lote);
		this.temperatura = temperatura;
	}

	public int getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(int temperatura) {
		this.temperatura = temperatura;
	}

	
	
}
