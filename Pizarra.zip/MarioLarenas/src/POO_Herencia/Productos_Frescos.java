package POO_Herencia;

import java.util.Date;

public class Productos_Frescos extends Productos{

	Date envasado;
	String origen;
	
	public Productos_Frescos() {
		super();
	}

	public Productos_Frescos(String nombre, Date caducidad, long lote, Date envasado, String origen) {
		super(nombre, caducidad, lote);
		this.envasado = envasado;
		this.origen = origen;
	}

	public Date getEnvasado() {
		return envasado;
	}

	public void setEnvasado(Date envasado) {
		this.envasado = envasado;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	
}
