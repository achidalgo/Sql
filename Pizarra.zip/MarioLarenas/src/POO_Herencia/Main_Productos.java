package POO_Herencia;

import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.text.MaskFormatter;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Main_Productos {

	   public static Date ParseFecha(String fecha)
	    {
	        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
	        Date fechaDate = null;
	        try {
	            fechaDate = formato.parse(fecha);
	        } 
	        catch (ParseException ex) 
	        {
	            System.out.println(ex);
	        }
	        return fechaDate;
	    }
	
	public static void main(String[] args) throws ParseException {
		
    MaskFormatter formatter = new MaskFormatter("##-##-####");
    JFormattedTextField textField = new JFormattedTextField(formatter);
    //JOptionPane.showMessageDialog(null, textField);
    
	Productos_Congelados PC = new Productos_Congelados(); 	
	Productos_Refrigerados PR = new Productos_Refrigerados();
	Productos_Frescos PF = new Productos_Frescos();
	
	PC.setNombre(JOptionPane.showInputDialog(null,"Ingrese Nombre"));
	PC.setCaducidad(ParseFecha(JOptionPane.showInputDialog("Ingrese Caducidad","dd/MM/yyyy")));	
	PC.setLote(Long.parseLong(JOptionPane.showInputDialog(null,"Ingrese Lote")));
	PC.setTemperatura(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese Temperatura")));
	
/*	PR.setNombre(JOptionPane.showInputDialog(null,"Ingrese Nombre"));
	PR.setCaducidad(ParseFecha(JOptionPane.showInputDialog("Ingrese Caducidad","dd/MM/yyyy")));
	PR.setLote(Long.parseLong(JOptionPane.showInputDialog(null,"Ingrese Lote")));
	PR.setOrganismo(JOptionPane.showInputDialog(null,"Ingrese Organismo"));
	
	PF.setNombre(JOptionPane.showInputDialog(null,"Ingrese Nombre"));
	PF.setCaducidad(ParseFecha(JOptionPane.showInputDialog("Ingrese Caducidad","dd/MM/yyyy")));
	PF.setLote(Long.parseLong(JOptionPane.showInputDialog(null,"Ingrese Lote")));
	PF.setEnvasado(ParseFecha(JOptionPane.showInputDialog("Ingrese Envasado","dd/MM/yyyy")));
	PF.setOrigen(JOptionPane.showInputDialog(null,"Ingrese Origen"));	*/
	
    System.out.println(PC.getCaducidad());
	
	}

}
