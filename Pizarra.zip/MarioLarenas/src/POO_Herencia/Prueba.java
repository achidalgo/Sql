package POO_Herencia;

public class Prueba {

	public static void main(String[] args) {
		int x=5;
		int y=x++;
		y=++x;
		int z=x++;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
	}

}
