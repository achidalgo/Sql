package POO_Herencia;

public class Practicante extends Persona{

    private int tipo;    //1. profesional o 2. practicante

	public Practicante() {
		super();
	}

	public Practicante(String nombre, int edad, double sueldo, int experiencia, int tipo) {
		super(nombre, edad, sueldo, experiencia);
		this.tipo=tipo;

	}
	
	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}	

    public void calculosalariopracticante(){
    	if (getTipo()==1)
    		setSueldo(900);
    	else 
    		setSueldo(450);
    }	
}
