package POO_Herencia;

public class Empleado extends Persona{

	public Empleado() {
		super();

	}

	public Empleado(String nombre, int edad, double sueldo, int experiencia) {
		super(nombre, edad, sueldo, experiencia);
	}

	
	
	
}
