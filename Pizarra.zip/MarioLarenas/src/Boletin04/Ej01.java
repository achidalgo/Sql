package Boletin04;
import java.util.Scanner;

public class Ej01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[5];
		
		for (int i=0; i<5; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
		for (int z=0; z<5; z++) {
			System.out.println(numeros[z]);
		}
		sc.close();
	}

}
