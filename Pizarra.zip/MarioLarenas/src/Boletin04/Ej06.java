package Boletin04;
import java.util.Scanner;

public class Ej06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros_a[] = new int[12]; 
		int numeros_b[] = new int[12];
		int numeros_c[] = new int[24];
		int i,j,z;
		j=0;
		for (i=0; i<12; i++) {
			System.out.print("Ingrese Numero A "+(i+1)+" ");
			numeros_a[i]=sc.nextInt();
		}
		for (i=0; i<12; i++) {
			System.out.print("Ingrese Numero B "+(i+1)+" ");
			numeros_b[i]=sc.nextInt();
		}
		for (i=0; i<12; i++) {
			for (z=0; z<3; z++) {
				numeros_c[j]=numeros_a[(i+z)];
				j++;
			}
			for (z=0; z<3; z++) {
				numeros_c[j]=numeros_b[(i+z)];
				j++;
			}
			i=i+2;
		}
		for (i=0; i<24; i++) {
			System.out.println(numeros_c[i]);
		}
		
		sc.close();
	}

}
