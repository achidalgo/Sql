package Boletin04;
import java.util.Scanner;

public class Ej08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10]; 
		int i, num, pos;
		for (i=0; i<8; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
		System.out.print("Ingrese Numero a insertar ");
		num=sc.nextInt();
		pos=0;
		do{
			System.out.print("Posicion 1 a 8 ");
			pos=sc.nextInt();		
		}while ((pos<1)||(pos>8));
	
		for (i=8;i>=(pos);i--) {
			numeros[i]=numeros[i-1];
			System.out.println("Puntero "+i+" ");
		}
		numeros[pos-1]=num;
		for (i=0; i<9; i++) {
			System.out.println(numeros[i]);
		}
		
       sc.close();
	}

}
