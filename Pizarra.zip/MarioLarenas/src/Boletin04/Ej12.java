package Boletin04;
import java.util.Scanner;

public class Ej12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10]; 
		int i, pos;
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
		System.out.print("Ingrese Posici�n a eliminar 0-9 ");
		pos=sc.nextInt();
		for (i=pos;i<9;i++) {
			numeros[i]=numeros[i+1];
		}
		numeros[9]=0;
		for (i=0; i<10; i++) {
			System.out.println(numeros[i]);
		}
		
       sc.close();
	}

}
