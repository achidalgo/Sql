package Boletin04;
import java.util.Scanner;

public class Ej04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10];
		int i,j;
		
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}

		j=9;
		for (i=0; i<5; i++) {
			System.out.println(numeros[i]);
			System.out.println(numeros[j]);//o (9-i)
			j--;
		}

		
		sc.close();
	}

}
