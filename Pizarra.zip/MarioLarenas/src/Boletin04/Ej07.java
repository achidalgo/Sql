package Boletin04;
import java.util.Scanner;

public class Ej07 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10]; 
        boolean asc, des, desorden;
		int i;
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
		asc=false;
		des=false;
		desorden=false;
		for (i=0; i<9; i++) {
			if (numeros[i]!=numeros[i+1]) {
				if ((numeros[i]>numeros[i+1]) && !asc) {
					des=true;
				}else if ((numeros[i]<numeros[i+1]) && !des){
					asc=true;
				}else {
					desorden=true;
				}
			}
		}
		
		if (desorden){
			System.out.println("Los numeros estan desordenados");
		}else if (asc) {
			System.out.println("Ordenados ascendentemente");
		}else {
			System.out.println("Ordenados descendentemente");
		}
		
       sc.close();
	}

}
