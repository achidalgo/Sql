package Boletin04;
import java.util.Scanner;

public class Ej09 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10]; 
		int i, primero;
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
        primero=numeros[9];
		for (i=9;i>0;i--) {
			numeros[i]=numeros[i-1];
		}
		numeros[0]=primero;
		for (i=0; i<10; i++) {
			System.out.println(numeros[i]);
		}
		
       sc.close();
	}

}
