package Boletin04;
import java.util.Scanner;

public class Ej05 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros_a[] = new int[10]; 
		int numeros_b[] = new int[10];
		int numeros_c[] = new int[20];
		int i,j;
		j=0;
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero A "+(i+1)+" ");
			numeros_a[i]=sc.nextInt();
		}
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero B "+(i+1)+" ");
			numeros_b[i]=sc.nextInt();
		}
		for (i=0; i<10; i++) {
			numeros_c[j]=numeros_a[i];
			j++;
			numeros_c[j]=numeros_b[i];
			j++;
		}
		for (i=0; i<20; i++) {
			System.out.println(numeros_c[i]);
		}
		
		sc.close();
	}

}
