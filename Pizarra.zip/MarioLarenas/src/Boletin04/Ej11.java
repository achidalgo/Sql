package Boletin04;
import java.util.Scanner;

public class Ej11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10]; 
		int i, num, pos;
		for (i=0; i<5; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
		System.out.print("Ingrese Numero a insertar ");
		num=sc.nextInt();
		pos=0;
		for (i=0;i<5;i++) {			
			if (num>numeros[i]) {
				pos=i+1;
				//System.out.println("Posicion "+pos);
			}
		}
		for (i=5;i>pos;i--) {
			numeros[i]=numeros[i-1];
		}
		numeros[pos]=num;
		for (i=0; i<6; i++) {
			System.out.println(numeros[i]);
		}
		
       sc.close();
	}

}
