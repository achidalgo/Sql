package Boletin04;
import java.util.Scanner;

public class Ej14 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros_a[] = new int[10]; 
		int numeros_b[] = new int[10];  
		int orden[] = new int[20];
		int i,  pos, aux;
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero A "+(i+1)+" ");
			numeros_a[i]=sc.nextInt();
		}
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero B "+(i+1)+" ");
			numeros_b[i]=sc.nextInt();
		}
        pos=0;
        aux=0;
		for (i=0;i<10;i++) {
			if (numeros_a[i]<=numeros_b[aux]) {
				orden[pos]=numeros_a[i];
				System.out.println("Posicion" +pos+" i "+i+" aux "+aux);
				pos++;
			}else {
				do {
					orden[pos]=numeros_b[aux];
					System.out.println("Posicion" +pos+" i "+i+" aux "+aux);
					aux++;
					pos++;
				}while (numeros_a[i]>numeros_b[aux]);
				if (numeros_a[i]<=numeros_b[aux]) {
					orden[pos]=numeros_a[i];
					System.out.println("Posicion" +pos+" i "+i+" aux "+aux);
					pos++;
				}
			}
		}
		if (aux<=9) {
			for (i=aux;i<10;i++) {
				orden[pos]=numeros_b[i];
				pos++;				
			}
		}
		
		for (i=0; i<20; i++) {
			System.out.println(orden[i]);
		}
		
       sc.close();
	}

}
