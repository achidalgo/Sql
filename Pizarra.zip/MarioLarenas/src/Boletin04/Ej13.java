package Boletin04;
import java.util.Scanner;

public class Ej13 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10]; 
		int orden[] = new int[10];
		int i, pos;
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
        pos=0;
		for (i=0;i<10;i+=2) {
			//indices pares
			orden[pos]=numeros[i];
			pos++;
		}
		
		for (i=1;i<10;i+=2) {
			//indices impares
			orden[pos]=numeros[i];
			pos++;
		}		
		for (i=0; i<10; i++) {
			System.out.println(orden[i]);
		}
		
       sc.close();
	}

}
