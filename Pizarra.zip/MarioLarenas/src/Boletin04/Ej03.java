package Boletin04;
import java.util.Scanner;

public class Ej03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[5];
		int i, suma_pos, cont_pos, suma_neg, cont_neg, cont_cero;
		
		for (i=0; i<5; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
		
		suma_pos=0;
		cont_pos=0;
		suma_neg=0;
		cont_neg=0;
		cont_cero=0;
		
		for (i=0; i<5; i++) {
			if (numeros[i]>0) {
			   suma_pos=suma_pos+numeros[i];
			   cont_pos++;
			}else if (numeros[i]<0){
				   suma_neg=suma_neg+numeros[i];
				   cont_neg++;				
			}else {
				cont_cero++;
			}
		}
		if (cont_pos>0) {
			System.out.println("La media de Positivos es "+(suma_pos/cont_pos));
		}
		if (cont_neg>0) {
			System.out.println("La media de Negativos es "+(suma_neg/cont_neg));
		}
		if (cont_cero>0) {
			System.out.println("La cantidad de ceros es "+cont_cero);
		}
		
		sc.close();
	}

}
