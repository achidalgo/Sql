package Boletin04;
import java.util.Scanner;

public class Ej10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[10]; 
		int i, j, desp;
		for (i=0; i<10; i++) {
			System.out.print("Ingrese Numero "+(i+1)+" ");
			numeros[i]=sc.nextInt();
		}
		System.out.print("Ingrese desplazamiento ");
		desp=sc.nextInt();
		j=0;
		int desplazados[]= new int[desp];
        for (i=(10-desp);i<10;i++) {
        	//System.out.println("I "+i+" J "+j);        	
        	desplazados[j]=numeros[i];
        	j++;
        }
		
		for (i=9;i>=desp;i--) {
        	//System.out.println("I "+i+" desp "+(i-desp));			
			numeros[i]=numeros[i-desp];

		}
		for (i=0;i<(desp);i++) {
			//System.out.println(i);
			numeros[i]=desplazados[i];
		}
		for (i=0; i<10; i++) {
			System.out.println(numeros[i]);
		}
		
       sc.close();
	}

}
