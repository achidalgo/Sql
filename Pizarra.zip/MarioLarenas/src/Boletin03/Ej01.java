package Boletin03;

public class Ej01 {
	public static void main(String[] args) {
		double suma=0;
		
		for(int i=1; i<=4; i++){
			for(int j=3; j>=0; j--) {
				suma=i*10+j;
				System.out.println("La suma es : "+suma);
			}
		}
	
	}
}
