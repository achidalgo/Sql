package Boletin03;

public class Ej02 {
	public static void main(String[] args) {
		int j=0;
		for(int i=1; i<=3; i++){
			j=i+1;
			//System.out.println("La i es : "+i);
			while(j<4) {
				//System.out.println("La j es : "+j);
				System.out.println("La resta es : "+(j-i));
				j++;
			}
		}
	
	}
}
