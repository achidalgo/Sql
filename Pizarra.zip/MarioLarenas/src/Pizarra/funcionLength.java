package Pizarra;

import java.util.Scanner;

public class funcionLength {

	private static Scanner sc;

	public static void main(String[] args) {
	sc = new Scanner(System.in);
		String nombre="Alumnos del curso Java Full Stack";
		int cantidad = nombre.length();//El largo de la cadena
		String nombremio;
		System.out.println("La cantidad de caracteres es : "+cantidad);
        System.out.print("Ingrese su nombre : ");
        nombremio=sc.nextLine();
		cantidad=nombremio.length();
		System.out.println("La cantidad de caracteres es : "+cantidad);
	}

}
