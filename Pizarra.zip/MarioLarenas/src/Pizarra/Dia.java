package Pizarra;
import java.util.Calendar;

public class Dia {

	public static void main(String[] args) {
	Integer dia= Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
	switch (dia) {
	case 1: System.out.println("Hoy es d�a Domingo");
			break;
	case 2: System.out.println("Hoy es d�a Lunes");
			break;
	case 3: System.out.println("Hoy es d�a Martes");
			break;
	case 4: System.out.println("Hoy es d�a Miercoles");
			break;
	case 5: System.out.println("Hoy es d�a Jueves");
			break;
	case 6: System.out.println("Hoy es d�a Viernes");
			break;
	case 7: System.out.println("Hoy es d�a Sabado");
			break;
	}
			
	}

}
