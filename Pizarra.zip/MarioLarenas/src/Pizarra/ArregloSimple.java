package Pizarra;

import java.util.Scanner;

public class ArregloSimple {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese numero de Alumnos");
		int n = sc.nextInt();
		String alumnos[] = new String[n];
		long telefono[] = new long[n];
		
		for (int i=0; i<=n-1; i++) {
			System.out.println("Ingrese Nombre del alumno "+(i+1));
			alumnos[i]=sc.next();
			System.out.println("Ingrese el telefono ");
			telefono[i]=sc.nextLong();
		}
		for (int z=0; z<=n-1; z++) {
			System.out.println("El alumno "+(z+1)+" es: "+alumnos[z]);
			System.out.println("Y su telefono es: "+telefono[z]);
		}
		sc.close();
	}

}
