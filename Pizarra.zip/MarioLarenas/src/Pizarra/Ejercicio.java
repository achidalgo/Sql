package Pizarra;
import java.util.Scanner;
public class Ejercicio {
    
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
    String alumnos[]= new String[10];
    float nota[]=new float[10];
    long telefono[]=new long[10];
    
    for (int i=0; i<10;i++) {
    	System.out.println("Ingrese nombre "+(i+1));
    	alumnos[i]=sc.nextLine();
    	System.out.println("Ingrese telefono "+(i+1));
    	telefono[i]=sc.nextLong();
    	System.out.println("Ingrese nota "+(i+1));
    	nota[i]=sc.nextFloat() ;	
    }
    for (int j=0; j<10;j++) {
    	if ((nota[j]>=5.5) && (nota[j]<=7)) {
    		System.out.println("Aprueba Excelente");
    	}
    	if ((nota[j]>=4.0) && (nota[j]<=5.4)) {
    		System.out.println("Aprueba por poco");
    	}
    	if ((nota[j]>=1.0) && (nota[j]<=3.9)) {
    		System.out.println("Reprueba");
    	}
    }
    for (int z=0; z<10;z++) {
    	if ((nota[z]>=5.5) && (nota[z]<=7)) {
    		System.out.println(alumnos[z]+" Aprueba Excelente");
    	}
    	if ((nota[z]>=4.0) && (nota[z]<=5.4)) {
    		System.out.println(alumnos[z]+" Aprueba por poco");
    	}
    	if ((nota[z]>=1.0) && (nota[z]<=3.9)) {
    		System.out.println(alumnos[z]+" Reprueba, llamar a "+telefono[z]);
    	}
    }
    
    //ordenar notas crecientes
    
	float aux0;
	String aux1;
	long aux2;
	for (int i = 0; i < nota.length; i++) {
		for (int k = 0; k < nota.length-i-1; k++) {
			if (nota[k]>nota[k+1]) {
				aux0=nota[k+1];
				nota[k+1]=nota[k];
				nota[k]=aux0;
				aux1=alumnos[k+1];
				alumnos[k+1]=alumnos[k];
				alumnos[k]=aux1;
				aux2=telefono[k+1];
				telefono[k+1]=telefono[k];
				telefono[k]=aux2;
	}

}
}
	sc.close();
	}
}
