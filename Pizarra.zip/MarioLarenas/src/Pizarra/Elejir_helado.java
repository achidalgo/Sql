package Pizarra;

import java.util.Scanner;

public class Elejir_helado {

	private static Scanner sc;

	public static void main(String[] args) {
	sc = new Scanner(System.in);
	int helado = 0;
	
	System.out.println("**************************************************");
	System.out.println("Elija un tipo de Helado  -> ");
	System.out.println("1.- Pi�a");
	System.out.println("2.- Naranja");
	System.out.println("3.- Mango");
	System.out.println("**************************************************");
	helado=sc.nextInt();

	switch (helado) {
	case 1: 
		System.out.println(" \\|/\r\n" + 
				" AXA\r\n" + 
				"/XXX\\\r\n" + 
				"\\XXX/\r\n" + 
				" `^'");
		break;
	case 2: 
	    System.out.println(" ,=.\r\n" + 
	    		"(.`:)\r\n" + 
	    		" `-'");
	    break;
	case 3: 
		System.out.println(" ,v.\r\n" + 
				"((  )\r\n" + 
				" `\"'");
		break;
	default: System.out.println("No ha seleccionado...correctamente "); 
	}
	}

}
