package Pizarra;
import java.util.Scanner;
public class Paseo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int temperatura;
		boolean nevando;
		System.out.print("Ingrese Temperatura ");
		temperatura=sc.nextInt();
		System.out.print("Esta Nevando ");
		nevando =sc.hasNext();
		
		if (temperatura>15) {
			if (temperatura>25) {
				System.out.println("A la playa!!!");
			}else {
				System.out.println("A la monta�a!!!");
			}
		}else if (temperatura<5) {
			if (nevando) {
				System.out.println("A esquiar!!!");
			}
		}else {
			System.out.println("A descansar ...zZz");
		}
		
	sc.close();	
	}//hay un rango que no se evalua 4 sin nieve o hace nada

}