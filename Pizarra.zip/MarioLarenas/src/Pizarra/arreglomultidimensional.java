package Pizarra;

import java.util.Scanner;

public class arreglomultidimensional {

	private static Scanner sc;

	public static void main(String[] args) {
	sc = new Scanner(System.in);
	
	String nombre[][]= new String[3][3];
	
	for (int i=0;i<3;i++) {

		for (int j=0;j<3;j++) {
			System.out.print("Ingrese nombre "+(i+1)+" "+(j+1)+" : ");
			nombre[i][j]=sc.nextLine();
		}
	}
	for (int i=0;i<3;i++) {

		for (int j=0;j<3;j++) {
			System.out.println("En la posici�n ["+(i+1)+"]["+(j+1)+"] : "+nombre[i][j]);
			
		}
	}	
	
	}

}
