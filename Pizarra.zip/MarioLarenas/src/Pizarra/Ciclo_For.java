package Pizarra;

public class Ciclo_For {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	for (int i=0; i<10; i++)	{
		System.out.println("Hola Participantes "+i);
		i=i+2;// para modificar incremento
		//i+=2;
	}
		
	}

}
