package Pizarra;
/*Contiene clases utiles para crear interfaces graficas 
 * y para dibujar figuras e imagenes*/

	import java.awt.*;  
	//import java.awt.event.*;
	
	public class Elejida2  
	{  
		Elejida2(){  
			
			/*Desplega una ventana emergente*/
	        Frame f= new Frame("Lista de Alumnos"); 
	        
	        /* Lista de datos para seleccionar un valor*/
	        List l1=new List(5);  
	        l1.setBounds(100,100, 90,75);  
	        l1.add("Alejandra");  
	        l1.add("Jaime");  
	        l1.add("Claudio");  
	        l1.add("Romina");  
	        l1.add("Pamela");  
	        l1.add("Natalia"); 
	        f.add(l1);  
	        
	        /* Campo de texto para ingresar datos*/
	        TextField t1,t2;  
	        t1=new TextField("Ingrese su email");  
	        t1.setBounds(100,200, 200,30);  
	        t2=new TextField("Ingrese su telefono");  
	        t2.setBounds(100,250, 200,30);  
	        f.add(t1); f.add(t2);	        
	        
	        /*Boton para ejecutar una acci�n programable*/
	        Button b=new Button("Aceptar");  
	        b.setBounds(100,300,80,30); 
	        //Cierra la ventana
	        b.addActionListener(e -> {
	            f.dispose();
	         });	        
	        f.add(b);  	        
	        
	        /*Parametros graficos de la ventana emergente*/
	        f.setSize(400,400);  
	        f.setLayout(null);  
	        f.setVisible(true);  
	      
	     }  
	public static void main(String args[])  
	{  
	   new Elejida2();  
	}  
	}  