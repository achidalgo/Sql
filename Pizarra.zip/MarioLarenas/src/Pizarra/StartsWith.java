package Pizarra;

import java.util.Scanner;

public class StartsWith {

	private static Scanner sc;

	public static void main(String[] args) {
	sc = new Scanner(System.in);
	
		String texto="Hola a todos";
		String nombre;
		boolean result = texto.startsWith("Ho");//comienza con..
		boolean resultfinal = texto.endsWith("Ho");//termina con..
		System.out.println("El resultado es : "+result);
		System.out.println("El resultado es : "+resultfinal);
		result=false;
		do {
			System.out.print("Ingrese su nombre : ");			
			nombre =sc.nextLine();
			result = nombre.startsWith("Ale");
		}while (!result);
		if (result) {
			System.out.println("As encontrado tu nombre");
		}
		
		String str="El primer programa";
		int pos =str.indexOf("p");//la primera posici�n
		System.out.println("La posici�n es : "+pos);
		pos =str.indexOf("p",pos+1);//la siguiente posici�n
		System.out.println("La posici�n es : "+pos);
		
		/*int N=str.length();
		int pos1=0;
		for (int i=0;i<N;) {
			pos1 =str.indexOf('p',i);
			System.out.println("La letra p se encuentra "+pos1+" i "+i+" N "+N);
			if (pos1>0) {i=i+pos1;}else {i=N;}
		}*/
		int N=str.length();
		int pos1=0;
		int aux=0;
		for (int i=0;i<N;i++) {
			pos1 =str.indexOf('p',pos1+i);
			if ((pos1>0)&&(pos!=aux)) {
				System.out.println("La letra p se encuentra "+pos1+" i "+i+" N "+N);
				aux=pos1;
				i=i+pos1;}else {i=N;}
		}		
		
		
	}

}
