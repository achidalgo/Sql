package Pizarra;

import java.util.Scanner;

public class Ingreso_datos_alumno {

	private static Scanner sc;

	public static void main(String[] args) {
	sc = new Scanner(System.in);
	
	String alumno[][]= new String[4][5];
	
	for (int i=0;i<4;i++) {
		System.out.println("Ingrese datos para el "+(i+1)+" alumno ->");
		System.out.print("Ingrese nombre : ");	alumno[i][0]=sc.nextLine();
		System.out.print("Ingrese apellido paterno : ");	alumno[i][1]=sc.nextLine();
		System.out.print("Ingrese apellido materno : ");	alumno[i][2]=sc.nextLine();
		System.out.print("Ingrese numero telefono : ");	alumno[i][3]=sc.nextLine();
		System.out.print("Ingrese email : ");	alumno[i][4]=sc.nextLine();			
	}

	for (int i=0;i<4;i++) {
		System.out.println("**************************************************");
		System.out.println("Nombre : "+alumno[i][0]+" "+alumno[i][1]+" "+alumno[i][2]);
		System.out.println("Numero telefono : "+alumno[i][3]);
		System.out.println("Email : "+alumno[i][4]);						
		}	
	String aux="";
	for (int i=0;i<4;i++) {
        if (alumno[i][0].length()>aux.length()){
        	aux=alumno[i][0];
        }
					
		}
	System.out.println("**************************************************");
	System.out.println("Nombre mas largo es "+aux+" "+(aux.length()));

	boolean hermanos=false;
	for (int i=0;i<3;i++) {
		for (int j=i+1;j<4;j++) {
			if ((alumno[i][1].equalsIgnoreCase(alumno[j][1]))&&(alumno[i][2].equalsIgnoreCase(alumno[j][2]))) {
				hermanos=true;
			}
		}
	}
	System.out.println("Hermanos "+hermanos);
}

}
