package Pizarra;
import java.util.Scanner;

public class arreglo_bidimensional {

	private static Scanner sc;

	public static void main(String[] args) {
		sc = new Scanner (System.in);
		
	String comida[][]= new String [3][4];
	
	for (int i=0;i<3;i++) {
		System.out.println("Ingrese comida dia "+(i+1)+" : ");
		for (int j=0; j<4;j++) {
			if (j==0) {
			System.out.print("Ingrese Desayuno : ");
			comida[i][j]=sc.next();
			}
			if (j==1) {
			System.out.print("Ingrese Almuerzo : ");
			comida[i][j]=sc.next();
			}
			if (j==2) {
			System.out.print("Ingrese Once : ");
			comida[i][j]=sc.next();
			}
			if (j==3) {
			System.out.print("Ingrese Cena : ");
			comida[i][j]=sc.next();
			}
		}
	}
	for (int i=0;i<3;i++) {
		for (int j=0; j<4;j++) {
			System.out.println(comida[i][j]);
		}
        System.out.println("***********************");	
	}
	}
}
