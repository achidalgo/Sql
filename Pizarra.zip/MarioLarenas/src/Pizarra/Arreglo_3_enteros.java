package Pizarra;
import java.util.Scanner;

public class Arreglo_3_enteros {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int edad[]= new int[3];
		
		for (int i=0; i<3; i++) {
			System.out.print("Ingrese el valor : "+(i+1));
			edad[i]=sc.nextInt();
		}
		for (int j=0; j<3; ) {
			System.out.println("Los valores del arreglo son : "+edad[j]);
			j++;
		}
		sc.close();
	}

}
