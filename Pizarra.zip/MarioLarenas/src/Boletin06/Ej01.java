package Boletin06;

public class Ej01 {

	public static void main(String[] args) {


	}

}
