package Evaluacion_02;
import javax.swing.JOptionPane;

public class Main_Persona {

	public static void main(String[] args) {
	
		Publico epublico = new Publico("152423566", "Fernando", "Mellado Salinas", "Los Laureles 45", 945281947, 780000, "Municipalidad de Los Alamos", "Administrativo");
		Privado eprivado = new Privado("123456787", "Francisco", "Risopatr�n De Lourdes", "Juan Bosco 1786", 976834616, 6000000, "Comuna Las Condes", "Gerencia");	
		
		 JOptionPane.showMessageDialog(null,  
			   " PUBLICO "
			+"\n Rut : "+epublico.getRut()						
			+"\n Nombre : "+epublico.getNombres()
		 	+"\n Apellidos : "+epublico.getApellido()
		 	+"\n Direccion : "+epublico.getDireccion()
		 	+"\n Telefono : "+epublico.getTelefono()
		 	+"\n Sueldo : "+epublico.getSueldo()
		 	+"\n Municipalidad : "+epublico.getMunicipalidad()	
		 	+"\n Departamento : "+epublico.getDepartamento()
			);	
		 JOptionPane.showMessageDialog(null,   
			   " PRIVADO"
			+"\n Rut : "+eprivado.getRut()
			+"\n Nombre : "+eprivado.getNombres()
			+"\n Apellidos : "+eprivado.getApellido()
			+"\n Direccion : "+eprivado.getDireccion()
			+"\n Telefono : "+eprivado.getTelefono()
			+"\n Sueldo : "+eprivado.getSueldo()
			+"\n Comuna : "+eprivado.getComuna()
			+"\n Empresa : "+eprivado.getEmpresa()
			);	
	}

}
