package Evaluacion_02;

public class Empleado_Ej04 {
	
	private String rut;
	private String nombres;
	private String apellido;
	private String direccion;
	private int telefono;
	private double sueldo;

	public Empleado_Ej04() {
		super();
	}

	public Empleado_Ej04(String rut, String nombres, String apellido, String direccion, int telefono, double sueldo) {
		super();
		this.rut = rut;
		this.nombres = nombres;
		this.apellido = apellido;
		this.direccion = direccion;
		this.telefono = telefono;
		this.sueldo = sueldo;
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	
	
}
