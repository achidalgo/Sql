package Evaluacion_02;
import java.util.Date;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;

public class Tarjeta {

	int numero;
	int tipo_usuario;//1.Comun, 2.TNE, 3.Bip
	int saldo;
	int descuento;//Beneficio
	Date dia_uso;
	
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	
	public Tarjeta() {
		super();
	}

	public Tarjeta(int numero, int tipo_usuario, int saldo, int descuento, Date dia_uso) {
		super();
		this.numero = numero;
		this.tipo_usuario = tipo_usuario;
		this.saldo = saldo;
		this.descuento = descuento;
		this.dia_uso = dia_uso;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getTipo_usuario() {
		return tipo_usuario;
	}

	public void setTipo_usuario(int tipo_usuario) {
		this.tipo_usuario = tipo_usuario;
	}

	public int getSaldo() {
		return saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}

	public int getDescuento() {
		return descuento;
	}

	public void setDescuento(int descuento) {
		this.descuento = descuento;
	}

	public Date getDia_uso() {
		return dia_uso;
	}

	public void setDia_uso(Date dia_uso) {
		this.dia_uso = dia_uso;
	}

	public void abono(int monto) {
		setSaldo(getSaldo()+monto);
		setDia_uso(new Date());
	}
	
	public void descuento_por_viaje(int monto) {
		if (getSaldo()>=(monto-getDescuento())){
			setSaldo(getSaldo()-(monto-getDescuento()));
			setDia_uso(new Date());
		}else {
			JOptionPane.showMessageDialog(null, " Saldo insuficiente, NO puede viajar");
		}
	}
	
	public void consultar() {
		 	JOptionPane.showMessageDialog(null, 
   		 			" TARJETA N� "+getNumero()
   		 			+"\n Tipo usuario : "+ verTipo(getNumero())
   		 			+"\n Saldo : "+ getSaldo()
   		 			+"\n Descuento : "+ getDescuento()
   		 			+"\n Vigencia : "+ formatter.format(getDia_uso())
				);
	}
	
	public void descuento_por_vigencia() {
				 
		Date fechaInicial=getDia_uso();
		Date fechaFinal=new Date();
 
		int dias=(int) ((fechaFinal.getTime()-fechaInicial.getTime())/86400000);
		
	 	JOptionPane.showMessageDialog(null, 
		 			" TARJETA N� "+getNumero()
		 			+"\n Tiene "+dias+" dias de inactividad");
	 	
		if (dias>365) 	setSaldo(0);
	}
	
	public String verTipo(int tu) {
		String tipo;
		switch(tu) {
		  case 1: tipo="Comun"; break;
		  case 2: tipo="TNE"; break;
		  case 3: tipo="Bip"; break;
		  default:
			  tipo="No definido";
		}
		return tipo;
	}
	
}
