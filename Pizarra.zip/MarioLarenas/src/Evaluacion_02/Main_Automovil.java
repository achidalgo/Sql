package Evaluacion_02;
import javax.swing.JFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
 
public class Main_Automovil {

	public static void main(String[] args)  {
		Automovil auto = new Automovil();
		
	    JLabel lmarca,lmodelo,la�o,lprecio; 	
	    JTextField tfmodelo,tfa�o,tfprecio;//, tfmarca;
	    JButton b1,b2;  
	   
	    JFrame f= new JFrame("Cotizar Automovil");  
	    lmarca= new JLabel("Marca");
	    lmarca.setBounds(50,50,100,20);
	    /*tfmarca=new JTextField();  
	    tfmarca.setBounds(150,50,150,20);*/ 
	
	    String marca[]={"Toyota","Kia","Ford","BWM","Mercedez"};        
	    JComboBox cbmarca=new JComboBox(marca);    
	    cbmarca.setBounds(150, 50,150,20);    
	    f.add(cbmarca); 
        
	    lmodelo=new JLabel("Modelo");
	    lmodelo.setBounds(50,100,150,20); 
	    tfmodelo=new JTextField();  
	    tfmodelo.setBounds(150,100,150,20); 
	    la�o=new JLabel("A�o");
	    la�o.setBounds(50,150,150,20);  
	    tfa�o=new JTextField();  
	    tfa�o.setBounds(150,150,150,20);  
	    lprecio=new JLabel("Precio");
	    lprecio.setBounds(50,200,150,20);	        
	    tfprecio=new JTextField();  
	    tfprecio.setBounds(150,200,150,20);
	          
	    b1=new JButton("Aceptar");  
	    b1.setBounds(50,250,100,30);  
	    b2=new JButton("Salir");  
	    b2.setBounds(200,250,100,30); 
	        
	    f.add(lmarca);f.add(lmodelo);f.add(la�o);f.add(lprecio);
	    //f.add(tfmarca);
	    f.add(tfmodelo);f.add(tfa�o);f.add(tfprecio);
	    f.add(b1);f.add(b2);  
	    f.setSize(400,400);  
	    f.setLayout(null);  
	    f.setVisible(true); 		
	
	    b1.addActionListener(new ActionListener() {
		
	    public void actionPerformed(ActionEvent e) {
	        	
	    	//auto.setMarca(tfmarca.getText()); 
	    	auto.setMarca(""+cbmarca.getItemAt(cbmarca.getSelectedIndex()));
	    	auto.setModelo(tfmodelo.getText());
	    	auto.setA�o(Integer.parseInt(tfa�o.getText())); 
	    	auto.setPrecio(Double.parseDouble(tfprecio.getText()));		
	    		
	   		JOptionPane.showMessageDialog(null,  
					   " AUTOMOVIL "
					+"\n Marca : "+auto.getMarca()					
					+"\n Modelo : "+auto.getModelo()
				 	+"\n A�o : "+auto.getA�o()
				 	+"\n Precio : "+auto.getPrecio()
				 	+"\n Precio Final : "+auto.preciofinal()
					);			
		  }	
		});
	    
	    b2.addActionListener(new ActionListener() {
			
	    	public void actionPerformed(ActionEvent e) {
	    		//if (e.getSource()==b2) {
	    			System.exit(0);
	    		//}
	    	}
		});	    
	    
	}
}
