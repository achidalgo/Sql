package Evaluacion_02;
import javax.swing.JOptionPane;

public class Main_Empleado_Ej02 {

	public static void main(String[] args) {
		
		Empleado_Ej02 e=new Empleado_Ej02();
		
		e.setRut(JOptionPane.showInputDialog(null,"Ingrese Rut"));
		e.setNombre(JOptionPane.showInputDialog(null,"Ingrese Nombre"));
		e.setApellidop(JOptionPane.showInputDialog(null,"Ingrese Apellido Paterno"));
		e.setApellidom(JOptionPane.showInputDialog(null,"Ingrese Apellido Materno"));
		e.setCargo(JOptionPane.showInputDialog(null,"Ingrese Cargo"));
		e.setDireccion(JOptionPane.showInputDialog(null,"Ingrese Direccion"));
	    e.setFono(Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese Telefono"))); 
		e.setEmail(JOptionPane.showInputDialog(null,"Ingrese Email"));	
		
		 JOptionPane.showMessageDialog(null,  
				   " EMPLEADO "
				+"\n Rut : "+ e.getRut()					
				+"\n Nombre : "+ e.getNombre()
			 	+"\n Apellido Paterno : "+ e.getApellidop()
			 	+"\n Apellido Materno : "+ e.getApellidom()
			 	+"\n Cargo : "+ e.getCargo()
			 	+"\n Direccion : "+ e.getDireccion()
			 	+"\n Telefono : "+ e.getFono()
			 	+"\n Email : "+ e.getEmail()
				);	
	}

}
