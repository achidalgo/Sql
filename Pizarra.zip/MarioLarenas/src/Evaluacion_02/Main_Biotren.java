package Evaluacion_02;

import javax.swing.JOptionPane;
import java.util.Date;

public class Main_Biotren {

	public static void main(String[] args)  {
        
        Tarjeta[] t =new Tarjeta[3];
        
	   	int op=0;
	   	int c=0;

	   	do {		      	
        	op=Integer.parseInt(JOptionPane.showInputDialog(""
        			+ "BIOTREN "
        			+ "\n Seleccione: "
        			+ "\n 1 Ingreso "
        			+ "\n 2 Abono "
        			+ "\n 3 Descuento por viaje "
        			+ "\n 4 Consultar "
        			+ "\n 5 Vigencia "
        			+ "\n 6 Salir"));
        	if(op==1) {//Ingreso
        		for (int i = 0; i < t.length; i++) {
        			t[i] = new Tarjeta();
        			t[i].setNumero(i+1);
        			t[i].setTipo_usuario(Integer.parseInt(JOptionPane.showInputDialog(""
                			+ "TARJETA N� "+(i+1)
                			+ "\n Seleccione tipo usuario: "
                			+ "\n 1 Comun "
                			+ "\n 2 TNE "
                			+ "\n 3 Bip")));    	
        			t[i].setSaldo(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese Saldo")));
           			t[i].setDescuento(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese Descuento")));
           			t[i].setDia_uso(new Date());

        		}
        	}
            if(op==2) {	//Abono
            	c=Integer.parseInt(JOptionPane.showInputDialog("Ingrese tarjeta a abonar"));
            	if (c>0 && c<=t.length) {
           		 	int a =Integer.parseInt(JOptionPane.showInputDialog(null, 
           		 			" TARJETA N� "+c
           		 			+"\n Saldo : "+ t[c-1].getSaldo()
      				));	
           		 	t[c-1].abono(a);
           		 	t[c-1].consultar();
           		 	
            	}else JOptionPane.showMessageDialog(null, " TARJETA no Valida");
            		
        	}
            if(op==3) {	//Descuento por viaje
            	c=Integer.parseInt(JOptionPane.showInputDialog("Ingrese tarjeta a descontar"));
            	if (c>0 && c<=t.length) {
           		 	int a =Integer.parseInt(JOptionPane.showInputDialog(null, 
           		 			" TARJETA N� "+c
           		 			+"\n Saldo : "+ t[c-1].getSaldo()
      				));	
           		 	t[c-1].descuento_por_viaje(a);
           		 	t[c-1].consultar();	
           		 	
            	}else JOptionPane.showMessageDialog(null, " TARJETA no Valida");
            		
        	}
            if(op==4) {	//Consultar
            	c=Integer.parseInt(JOptionPane.showInputDialog("Ingrese tarjeta a consultar"));
            	if (c>0 && c<=t.length) {
            		t[c-1].consultar();
	
            	}else JOptionPane.showMessageDialog(null, " TARJETA no Valida");
            		
        	}
            if(op==5) { //Validar vigencia
            	c=Integer.parseInt(JOptionPane.showInputDialog("Ingrese tarjeta para ver vigencia"));
            	if (c>0 && c<=t.length) {
            		t[c-1].descuento_por_vigencia();
            		t[c-1].consultar();
	
            	}else JOptionPane.showMessageDialog(null, " TARJETA no Valida");
            		
        	}
    	}while(op!=6);
    			
	}

}
